package com.example.yys.fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ExifInterface;
import android.media.ThumbnailUtils;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.yys.MainActivity;
import com.example.yys.R;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import static android.content.ContentValues.TAG;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.ViewHolder> {

    private Context context;
    private ArrayList<MyData> mDataset;


    public static class ViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public ImageView mImageView;
        public TextView mTextView;
        public TextView mTextView2;


        public ViewHolder(View view) {
            super(view);
            mImageView = (ImageView) view.findViewById(R.id.imageView);
            mTextView = (TextView) view.findViewById(R.id.info_text);
            mTextView2 = (TextView) view.findViewById(R.id.main_text);



        }


    }


    public MyAdapter(FragmentActivity activity, ArrayList<MyData> myDataset) {
        mDataset = myDataset;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public MyAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // create a new view
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.my_card_view, parent, false);


        // set the view's size, margins, paddings and layout parameters
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }


    @Override
    public void onBindViewHolder(@NonNull MyAdapter.ViewHolder holder, int position) {

        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES), "yys");
        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.d("yys", "failed to create directory");
//                return null;
            }
        }
        String mBasePath = mediaStorageDir.getPath();

        File file = new File(mBasePath); // 지정 경로의 directory를 File 변수로 받아
        if (!file.exists()) {
            if (!file.mkdirs()) {
                Log.d(TAG, "failed to create directory");
            }
        }
        String[] text = file.list();

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;

        int width = options.outWidth;
        int height = options.outHeight;
        int inSampleSize = 1;
        int reqWidth = 256;
        int reqHeight = 192;
        if ((width > reqWidth) || (height > reqHeight)) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) > reqHeight
                    && (halfWidth / inSampleSize) > reqWidth) {
                inSampleSize *= 2;
            }
        }
        options.inSampleSize = inSampleSize;
        options.inJustDecodeBounds = false;

        Bitmap bm = BitmapFactory.decodeFile(mBasePath + File.separator + text[position], options);



        holder.mTextView.setText("#" + mDataset.get(position).infotext[position]);
        holder.mImageView.setImageBitmap(bm);
        holder.mTextView2.setText("#");



    }

    @Override
    public int getItemCount() {
        return mDataset.size();

    }

}


class MyData{
    public String[] infotext;
    public int index;
    public Bitmap bm;// 지정 경로의 사진을 Bitmap으로 받아오기 위한 변수
    public byte[] bytes;


    public MyData(int index,String[] infotext, Bitmap bm){

        this.index = index;
        this.bm = bm;
        this.infotext = infotext;

    }

}
/*
class MyData implements Comparable<MyData>{
    public String[] infotext;
    public int index;
    public Bitmap bm;

    public MyData(int index, String[] infotext, Bitmap bm)
    {
        this.index = index;
        this.bm = bm;
        this.infotext = infotext;
    }

    @Override
    public int compareTo(MyData myData) {
        return myData.infotext.compareTo(this.infotext);
    }
}*/