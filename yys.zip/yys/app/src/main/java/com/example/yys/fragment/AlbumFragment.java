package com.example.yys.fragment;


import android.app.VoiceInteractor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Gallery;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;


import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.example.yys.R;

import java.io.File;

public class AlbumFragment extends Fragment {
    ViewPager viewpager;

    public static final int MEDIA_TYPE_IMAGE = 1;
    public static final int MEDIA_TYPE_VIDEO = 2;
    public int inSampleSize = 1;

    private static final int CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE = 100;
    private Uri fileUri;
    private static String basePath;

    public float imageViewRotation = 90;
    public String TAG = "Camera Example :: ";

    private ImageView resultView;
    private TextView imgPath;
    private Gallery customGallery;
    private GalleryAdapter galleryAdapter;

    private String[] imgs;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.album_fragment, container, false);

        super.onCreate(savedInstanceState);

        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES), "yys");
        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (! mediaStorageDir.exists()){
            if (! mediaStorageDir.mkdirs()){
                Log.d("yys", "failed to create directory");
//                return null;
            }
        }
        basePath = mediaStorageDir.getPath();




        imgPath = (TextView) view.findViewById(R.id.imgpath);
        resultView = (ImageView) view.findViewById(R.id.resultview);


        File file = new File(basePath);
        imgs = file.list();
        for (int i = 0; i < imgs.length; i++) {
            imgPath.setText(imgs[i]);
        }

        customGallery = (Gallery) view.findViewById(R.id.customgallery); // activity_main.xml에서 선언한 Gallery를 연결
        galleryAdapter = new GalleryAdapter(getActivity(), basePath); // 위 Gallery에 대한 Adapter를 선언
        customGallery.setAdapter(galleryAdapter); // Gallery에 위 Adapter를 연결
        // Gallery의 Item을 Click할 경우 ImageView에 보여주도록 함
        customGallery.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Bitmap bm = BitmapFactory.decodeFile(basePath + File.separator + imgs[position]);
                Bitmap bm2 = ThumbnailUtils.extractThumbnail(bm, bm.getWidth() / inSampleSize, bm.getHeight() / inSampleSize);
                resultView.setImageBitmap(bm2);
                imgPath.setText(basePath + File.separator + imgs[position]);
            }
        });
        return view;

    }
}

/*public class AlbumFragment extends Fragment {
    ViewPager viewPager;

    private int[] imageIDs = new int[] {
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
            R.drawable.yysplash,
    };


    public AlbumFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.album_fragment, container, false);

        GridView gridView = (GridView) view.findViewById(R.id.gridView);
        ImageAdapter imageAdapter = new ImageAdapter(getActivity(), imageIDs);
        gridView.setAdapter(imageAdapter);

        return view;

    }

}
*/

