package com.example.yys;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.Window;
import android.widget.GridView;
import android.widget.TextView;

import androidx.annotation.Nullable;

import java.io.File;

public class CalendarAlbum extends Activity {

    public GridView gridView;
    public TextView textView;
    public ImageAdapter imageAdapter;
    public String basePath= null;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState, @Nullable PersistableBundle persistentState) {
        super.onCreate(savedInstanceState, persistentState);

        setContentView(R.layout.calendaralbum_activity);
        requestWindowFeature(getWindow().FEATURE_NO_TITLE);



        gridView = (GridView)findViewById(R.id.gridView);
        textView = (TextView)findViewById(R.id.date_text);
        imageAdapter = new ImageAdapter(this, basePath);
        gridView.setAdapter(imageAdapter);



    }
}
