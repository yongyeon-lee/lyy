package com.example.yys.fragment;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ExifInterface;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.DateSorter;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.example.yys.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.lang.reflect.Array;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.SortedSet;

import com.example.yys.fragment.AlbumFragment;

import static android.content.ContentValues.TAG;


public class TimelineFragment extends Fragment {
    ViewPager viewPager;

    private RecyclerView recyclerView;
    private MyAdapter mAdapter;
    ArrayList<MyData> mDataset;
    private static String mBasePath;
    String[] infotext;
    Bitmap bm;
    int i;


    public TimelineFragment() {

        ImageView imageView;

    }

    @NonNull
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.timeline_fragment, container, false);

        super.onCreate(savedInstanceState);



        recyclerView = (RecyclerView) view.findViewById(R.id.my_recycler_view);
        mDataset = new ArrayList<>();
        recyclerView.setHasFixedSize(true);
        mAdapter = new MyAdapter(getActivity(), mDataset);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(mAdapter);

        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES), "yys");
        // This location works best if you want the created images to be shared
        // between applications and persist after your app has been uninstalled.

        // Create the storage directory if it does not exist
        if (! mediaStorageDir.exists()){
            if (! mediaStorageDir.mkdirs()){
                Log.d("yys", "failed to create directory");
//                return null;
            }
        }
        mBasePath = mediaStorageDir.getPath();

        File file = new File(mBasePath); // 지정 경로의 directory를 File 변수로 받아
        if (!file.exists()) {
            if (!file.mkdirs()) {
                Log.d(TAG, "failed to create directory");
            }
        }
        infotext = file.list();

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;

        int width = options.outWidth;
        int height = options.outHeight;
        int inSampleSize = 1;
        int reqWidth = 256;
        int reqHeight = 192;
        if((width > reqWidth) || (height > reqHeight)){
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) > reqHeight
                    && (halfWidth / inSampleSize) > reqWidth) {
                inSampleSize *= 2;
            }
        }
        options.inSampleSize = inSampleSize;
        options.inJustDecodeBounds = false;

        bm = BitmapFactory.decodeFile(mBasePath+ File.separator +infotext[i], options);



        for(i=0;i<infotext.length;i++) {

            mDataset.add(new MyData(i ,infotext ,bm));

        }

        /*mDataset.add(new MyData("#" , R.mipmap.ic_launcher));
        mDataset.add(new MyData("#Mini", R.mipmap.ic_launcher));
        mDataset.add(new MyData("#ToyStroy", R.mipmap.ic_launcher));
        mDataset.add(new MyData("#",R.mipmap.ic_launcher_round));*/


        return view;

    }




}


