package com.applandeo.materialcalendarview.listeners;

/**
 * Created by Mateusz Kornakiewicz on 12.10.2017.
 */

public interface OnCalendarPageChangeListener {
    void onChange();
}
